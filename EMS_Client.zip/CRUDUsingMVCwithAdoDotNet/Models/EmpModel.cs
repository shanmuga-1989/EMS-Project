﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EmployeeMVC.Models
{
    public class EmpModel
    {
        [Display(Name = "Id")]
        public int ID { get; set; }

        [Display(Name = "Emp ID")]
        public string EmpID { get; set; }

        [Required(ErrorMessage = "First name is required.")]
        [StringLength(50, ErrorMessage = "Name cannot be longer than 50 characters.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Address is required.")]
        [StringLength(50, ErrorMessage = "Name cannot be longer than 50 characters.")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Gender is required.")]
        [StringLength(6, ErrorMessage = "Name cannot be longer than 6 characters.")]
        public string Gender { get; set; }
        
        [Display(Name = "Company")]
        public string Company { get; set; }

        [Required(ErrorMessage = "Designation is required.")]
        [StringLength(25, ErrorMessage = "Name cannot be longer than 25 characters.")]
        public string Designation { get; set; }

        [Required(ErrorMessage = "Mobile is required.")]
        [StringLength(10, ErrorMessage = "Name cannot be longer than 10 characters.")]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Mobile no sould be a 10 digit number)")]
        public string Mobile { get; set; }
        

        //public List<EmpModel> ShowallEmployee { get; set; }



    }

 

}
