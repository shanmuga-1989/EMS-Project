﻿using System.Web.Mvc;
using EmployeeMVC.Models;
using EmployeeMVC.Repository;
using System.Collections.Generic;
using System.Linq;


namespace EmployeeMVC.Controllers
{

    public class EmployeeController : Controller
    {
        private iEmployee _IEmp;
        public EmployeeController()
        {
            _IEmp = EmpRepository.GetInstance;
        }

        // GET: Employee/GetAllEmpDetails
        public ActionResult GetAllEmpDetails()
        {
          
           
            ModelState.Clear();
            return View(_IEmp.GetAllEmployees());
        }
        // GET: Employee/AddEmployee
        public ActionResult AddEmployee()
        {
            return View();
        }

        // POST: Employee/AddEmployee
        [HttpPost]
        public ActionResult AddEmployee(EmpModel Emp)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    //EmpRepository EmpRepo = new EmpRepository();

                    if (_IEmp.AddEmployee(Emp))
                    {
                        ViewBag.Message = "Employee details added successfully";
                    }
                }
              
                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/EditEmpDetails/5
        public ActionResult EditEmpDetails(int id)
        {
           // EmpRepository EmpRepo = new EmpRepository();

            List<EmpModel> emp = _IEmp.GetAllEmployees().ToList();

            return View(emp.Find(Emp => Emp.ID == id));

        }

        // POST: Employee/EditEmpDetails/5
        [HttpPost]
      
        public ActionResult EditEmpDetails(int id,EmpModel obj)
        {
            try
            {
                //  EmpRepository EmpRepo = new EmpRepository();

                _IEmp.UpdateEmployee(obj);
                return RedirectToAction("GetAllEmpDetails");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/DeleteEmp/5
        public ActionResult DeleteEmp(int id)
        {
            try
            {
               // EmpRepository EmpRepo = new EmpRepository();
                if (_IEmp.DeleteEmployee(id))
                {
                    ViewBag.AlertMsg = "Employee details deleted successfully";

                }
                return RedirectToAction("GetAllEmpDetails");

            }
            catch
            {
                return View();
            }
        }

   
    }
}
