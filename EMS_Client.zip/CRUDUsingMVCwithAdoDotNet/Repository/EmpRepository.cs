﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using EmployeeMVC.Models;
using System.Net.Http;
using System.Linq;
using Newtonsoft.Json;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using EmployeeMVC.Repository;

namespace EmployeeMVC.Repository
{
    public class EmpRepository: iEmployee
    {
        private EmpRepository()
        {
        }
        private static readonly Lazy<EmpRepository> instance = new Lazy<EmpRepository>(() => new EmpRepository());

        public static EmpRepository GetInstance
        {
            get
            {
                return instance.Value;
            }
        }


        //To Add Employee details
        public bool AddEmployee(EmpModel obj)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://ems-app.azurewebsites.net");

                    //HTTP POST
                    var postTask = client.PostAsJsonAsync<EmpModel>("/api/Employee/AddEmployee", obj);
                    postTask.Wait();

                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        return true;
                    }
                }


            }
            catch
            {

            }
            return false;

        }
        //To view employee details with generic list 
        public IEnumerable<EmpModel> GetAllEmployees()
        {
            try
            {


                IEnumerable<EmpModel> EmpList = null;

                using (var clientobj = new HttpClient())
                {
                    clientobj.BaseAddress = new Uri("https://ems-app.azurewebsites.net");

                    var responseTask = clientobj.GetAsync("/api/Employee/GetAllEmployee");
                    responseTask.Wait();
                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<IList<EmpModel>>();
                        readTask.Wait();

                        EmpList = readTask.Result;
                    }
                    else
                    {
                        EmpList = Enumerable.Empty<EmpModel>();

                    }
                }
                return EmpList;
            }
            catch
            {
                return null;
            }
        }


        //To Update Employee details
        public bool UpdateEmployee(EmpModel obj)
        {

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://ems-app.azurewebsites.net");

                //HTTP POST
                var postTask = client.PutAsJsonAsync<EmpModel>("/api/Employee/UpdateEmployee", obj);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return true;
                }
            }
            return false;


        }
        //To delete Employee details
        public bool DeleteEmployee(int Id)
        {




            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://ems-app.azurewebsites.net");

                //HTTP DELETE
                var deleteTask = client.DeleteAsync("/api/Employee/Delete/" + Id);
                deleteTask.Wait();

                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return true;
                }
                return false;

            }
        }
    }
}