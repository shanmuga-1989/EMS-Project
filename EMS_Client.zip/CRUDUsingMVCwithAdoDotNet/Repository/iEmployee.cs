﻿using EmployeeMVC.Models;
using System.Collections.Generic;

namespace EmployeeMVC.Repository
{
    public interface iEmployee
    {
        bool AddEmployee(EmpModel obj);
        IEnumerable<EmpModel> GetAllEmployees();
        bool UpdateEmployee(EmpModel obj);
        bool DeleteEmployee(int Id);
    }
}