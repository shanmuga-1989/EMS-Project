﻿using EmployeeAPI.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace EmployeeAPI.Controllers
{
    public class EmployeeController : ApiController
    {
        [HttpGet]
        [ActionName("GetEmployeeByID")]
        public Employee GetEmployeeByID(int id)
        {
            Employee emp = null;
            try
            {
                DataAccessLayer da = new DataAccessLayer();
                emp =  da.GetEmployeeByID(id);
                return emp;
            }
            catch
            {
                return emp;
            }
            finally
            {
                emp = null;
            }

        }

        [HttpPost]
        [ActionName("AddEmployee")]
        public string AddEmployee([FromBody]Employee employee)
        {
            string result = "";
            if (ModelState.IsValid)
            {
                try
                {
                    DataAccessLayer da = new DataAccessLayer();
                    result = da.AddEmployee(employee);
                    return result;

                }
                catch (Exception ex)
                {
                    return ex.Message.ToString();
                }
            }
            else
            {
                return result = "Please enter the valid request parameters";
            }

           
        }

        public HttpResponseMessage Delete(int ID)
        {
          
            var result = new HttpResponseMessage(HttpStatusCode.OK);
            try
            {
                DataAccessLayer da = new DataAccessLayer();
               string res = da.DeleteEmployee(ID);
                return Request.CreateResponse(HttpStatusCode.OK, res);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest,ex.Message.ToString());
              
            }
           
        }

        [HttpGet]
        [ActionName("GetAllEmployee")]
        public HttpResponseMessage GetAllEmplotyee()
        {
            SqlConnection con = null;

            DataSet ds = null;
            List<Employee> custlist = null;
         
            string strResult ="";
            try
            {
                DataAccessLayer da = new DataAccessLayer();
                var custlists = da.GetAllEmplotyee();
                strResult = JsonConvert.SerializeObject(custlist);
                return Request.CreateResponse(HttpStatusCode.OK, custlists); 
            }
            catch
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, strResult); 
            }
            finally
            {
                custlist = null;
            }
        }
        [HttpPut]
        [ActionName("UpdateEmployee")]
        public string UpdateEmployee([FromBody]Employee emp)
        {
            string result = "";
            if (ModelState.IsValid)
            {
                try
                {
                    DataAccessLayer da = new DataAccessLayer();
                    result = da.UpdateEmployee(emp);
                    return result;
                }
                catch
                {
                    return result = "";
                }
            }
            else
            {
                return result = "Please enter the valid request parameters";
            }
           


        }
    }
}
