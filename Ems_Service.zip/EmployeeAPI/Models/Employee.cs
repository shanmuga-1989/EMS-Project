﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EmployeeAPI.Models
{
    public class Employee
    {
        [Required]
        public int ID { get; set; }

        public string EmpID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public string Gender { get; set; }

    
        public string Company { get; set; }

        [Required]
        public string Designation { get; set; }

        [RegularExpression("^[0-9]{10}$")]
        public string Mobile { get; set; }
        
    }
}