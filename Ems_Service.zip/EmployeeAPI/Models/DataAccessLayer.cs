﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace EmployeeAPI.Models
{
    public class DataAccessLayer
    {
        public Employee GetEmployeeByID(int id)
        {
            SqlConnection con = null;
            DataSet ds = null;
            Employee emp = null;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
                SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_Employees", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.Parameters.AddWithValue("@Name", null);
                cmd.Parameters.AddWithValue("@Mobileno", null);
                cmd.Parameters.AddWithValue("@Address", null);
                cmd.Parameters.AddWithValue("@Company", null);
                cmd.Parameters.AddWithValue("@Gender", null);
                cmd.Parameters.AddWithValue("@Designation", null);
                cmd.Parameters.AddWithValue("@Query", 5);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    emp = new Employee();
                    emp.ID = Convert.ToInt32(ds.Tables[0].Rows[i]["ID"].ToString());
                    emp.EmpID = ds.Tables[0].Rows[i]["EMPId"].ToString();
                    emp.Name = ds.Tables[0].Rows[i]["Name"].ToString();
                    emp.Mobile = ds.Tables[0].Rows[i]["Mobile"].ToString();
                    emp.Address = ds.Tables[0].Rows[i]["Address"].ToString();
                    emp.Gender = ds.Tables[0].Rows[i]["Gender"].ToString();
                    emp.Company = ds.Tables[0].Rows[i]["Company"].ToString();
                    emp.Designation = ds.Tables[0].Rows[i]["Designation"].ToString();
                }
                return emp;
            }
            catch
            {
                return emp;
            }
            finally
            {
                con.Close();
            }

        }
        
        public string AddEmployee(Employee employee)
        {
            SqlConnection con = null;
            string result = "";
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
                SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_Employees", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", 0);
                cmd.Parameters.AddWithValue("@Name", employee.Name);
                cmd.Parameters.AddWithValue("@Mobileno", employee.Mobile);
                cmd.Parameters.AddWithValue("@Address", employee.Address);
                cmd.Parameters.AddWithValue("@Company", employee.Company);
                cmd.Parameters.AddWithValue("@Gender", employee.Gender);
                cmd.Parameters.AddWithValue("@Designation", employee.Designation);
                cmd.Parameters.AddWithValue("@Query", 1);

           
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
            finally
            {
                con.Close();
            }
        }
        
        public string DeleteEmployee(int ID )
        {
            SqlConnection con = null;
            string result = "";
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
                SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_Employees", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", ID);
                cmd.Parameters.AddWithValue("@Name", null);
                cmd.Parameters.AddWithValue("@Mobileno", null);
                cmd.Parameters.AddWithValue("@Address", null);
                cmd.Parameters.AddWithValue("@Company", null);
                cmd.Parameters.AddWithValue("@Gender", null);
                cmd.Parameters.AddWithValue("@Designation", null);
                cmd.Parameters.AddWithValue("@Query", 3);

                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
            finally
            {
                con.Close();
            }
        }
        
        public List<Employee> GetAllEmplotyee()
        {
            SqlConnection con = null;

            DataSet ds = null;
            List<Employee> custlist = null;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
                SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_Employees", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", null);
                cmd.Parameters.AddWithValue("@Name", null);
                cmd.Parameters.AddWithValue("@Mobileno", null);
                cmd.Parameters.AddWithValue("@Address", null);
                cmd.Parameters.AddWithValue("@Company", null);
                cmd.Parameters.AddWithValue("@Gender", null);
                cmd.Parameters.AddWithValue("@Designation", null);
                cmd.Parameters.AddWithValue("@Query", 4);           
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                custlist = new List<Employee>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    Employee emp = new Employee();
                    emp.ID = Convert.ToInt32(ds.Tables[0].Rows[i]["ID"].ToString());
                    emp.EmpID = ds.Tables[0].Rows[i]["EMPId"].ToString();
                    emp.Name = ds.Tables[0].Rows[i]["Name"].ToString();
                    emp.Mobile = ds.Tables[0].Rows[i]["Mobile"].ToString();
                    emp.Address = ds.Tables[0].Rows[i]["Address"].ToString();
                    emp.Gender = ds.Tables[0].Rows[i]["Gender"].ToString();
                    emp.Company = ds.Tables[0].Rows[i]["Company"].ToString();
                    emp.Designation = ds.Tables[0].Rows[i]["Designation"].ToString();

                    custlist.Add(emp);
                }
                return custlist;
            }
            catch
            {
                return custlist;
            }
            finally
            {
                con.Close();
            }
        }
      
        public string UpdateEmployee(Employee emp)
        {
            SqlConnection con = null;
            string result = "";
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
                SqlCommand cmd = new SqlCommand("Usp_InsertUpdateDelete_Employees", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", emp.ID);
                cmd.Parameters.AddWithValue("@Name", emp.Name);
                cmd.Parameters.AddWithValue("@Mobileno", emp.Mobile);
                cmd.Parameters.AddWithValue("@Address", emp.Address);
                cmd.Parameters.AddWithValue("@Company", emp.Company);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@Designation", emp.Designation);
                cmd.Parameters.AddWithValue("@Query", 2);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
            finally
            {
                con.Close();
            }
        }
    }
}